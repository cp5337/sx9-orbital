# SX9-ORBITAL MEMORY CONFIGURATION
## Headless Compressed Memory Setup - Complete Edition

**System:** sx9-orbital  
**Version:** 2.0.0  
**Memory Model:** R0-R3 Layered Registers  
**Includes:** Linear + Slack control surface integration

---

## MEMORY ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────┐
│              HEADLESS COMPRESSED MEMORY                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  R0: Identity Layer (Always Loaded, ~600 tokens)                │
│  ═══════════════════════════════════════════════                │
│  • System identity and compliance                               │
│  • Control surface configuration                                │
│  • Bernoulli zone constraints                                   │
│                                                                 │
│  R1: Domain Knowledge (Semantic Hashes, ~2500 tokens)           │
│  ═══════════════════════════════════════════════════            │
│  • Constellation specs                                          │
│  • Routing algorithms                                           │
│  • Control surface commands                                     │
│                                                                 │
│  R2: Task Context (Sliding Window, ~1000 tokens)                │
│  ════════════════════════════════════════════════               │
│  • Current task from Linear/GitHub                              │
│  • Active simulation state                                      │
│                                                                 │
│  R3: Recent Decisions (Audit Trail, ~500 tokens)                │
│  ═══════════════════════════════════════════════                │
│  • Routing decisions                                            │
│  • Station additions                                            │
│  • Backtest results                                             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## R0: IDENTITY REGISTER (Always Loaded)

```json
{
  "system": {
    "name": "sx9-orbital",
    "type": "satellite_constellation_platform",
    "version": "2.0.0"
  },
  "owner": {
    "org": "SYNAPTIX",
    "type": "SDVOSB",
    "operator": "Charles E. Payne"
  },
  "mission": {
    "primary": "Simulate HALO constellation for Laser Light Communications",
    "secondary": "Weather-aware FSO routing optimization",
    "deliverable": "DTaaS platform for defense contractors"
  },
  "compliance": {
    "itar": true,
    "ear": true,
    "cmmc_level": 2,
    "cato_required": true,
    "fips_140_3": true
  },
  "constraints": {
    "zone_classification": "B",
    "latency_target_ms": 50,
    "llm_zones_forbidden": ["A", "B", "C"],
    "llm_zone_allowed": "D"
  },
  "surfaces": {
    "slack": {
      "channel": "#sx9-orbital",
      "commands": ["/orbital", "/sat", "/station", "/routing", "/backtest"]
    },
    "linear": {
      "project": "sx9-orbital",
      "labels": ["SATELLITE", "STATION", "ROUTING", "BACKTEST", "WEATHER", "COMPLIANCE"]
    },
    "github": {
      "repo": "synaptix/sx9-orbital",
      "webhooks": ["push", "pr", "release"]
    }
  },
  "factory": {
    "registered": true,
    "current_phase": "plan"
  }
}
```

### R0 Compressed (T-Line Format)
```
$.id.system = "sx9-orbital|constellation|v2.0"
$.id.owner = "SYNAPTIX|SDVOSB|charles"
$.id.mission = "HALO|LaserLight|DTaaS|defense"
$.id.compliance = "ITAR|EAR|CMMC2|cATO|FIPS"
$.id.zone = "B|50ms|NO_LLM_ABC"
$.id.slack = "#sx9-orbital|/orbital,/sat,/station,/routing,/backtest"
$.id.linear = "sx9-orbital|SAT,STATION,ROUTING,BACKTEST"
```

---

## R1: DOMAIN KNOWLEDGE REGISTER (Semantic Hashes)

```json
{
  "constellation": {
    "$.orbital.halo": {
      "hash": "0x7A3F8B2C",
      "expansion": "12 MEO satellites, 10500km, Walker Delta 3/4, 3 planes, 4 sats/plane, mid Van Allen"
    },
    "$.orbital.walker": {
      "hash": "0x2D4E6F8A",
      "expansion": "Walker Delta notation: i:t/p/f where i=inclination, t=total sats, p=planes, f=phasing"
    },
    "$.orbital.sgp4": {
      "hash": "0x9B1C3D5E",
      "expansion": "Simplified General Perturbations 4, TLE input, ECI output, position+velocity"
    }
  },
  "ground_segment": {
    "$.ground.stations": {
      "hash": "0x4F6A8C2E",
      "expansion": "257 Airbus FSO stations, global distribution, validated lat/long required"
    },
    "$.ground.fso": {
      "hash": "0x1E3G5I7K",
      "expansion": "Free-space optical, weather dependent, 200 Gbps per link, beam quality scoring"
    }
  },
  "routing": {
    "$.routing.ann": {
      "hash": "0x8H2J4L6N",
      "expansion": "ANN/CNN routing: weather state + satellite positions + demand → optimal path"
    },
    "$.routing.backtest": {
      "hash": "0x3M5O7Q9S",
      "expansion": "HFT-style backtesting, 5 years weather data, tick-by-tick, Monte Carlo"
    },
    "$.routing.quality": {
      "hash": "0x6P8R0T2V",
      "expansion": "BeamQuality: optical + geometric + atmospheric + availability → composite"
    }
  },
  "coordinates": {
    "$.coord.eci": {
      "hash": "0x5U7W9Y1A",
      "expansion": "Earth-Centered Inertial, propagation frame, non-rotating"
    },
    "$.coord.ecef": {
      "hash": "0x2B4D6F8H",
      "expansion": "Earth-Centered Earth-Fixed, ground reference, rotating"
    },
    "$.coord.geodetic": {
      "hash": "0x9J1L3N5P",
      "expansion": "Lat/Lon/Alt, ground stations, MUST VALIDATE: lat[-90,90] lon[-180,180]"
    }
  },
  "compliance": {
    "$.compliance.itar": {
      "hash": "0x4Q6S8U0W",
      "expansion": "International Traffic in Arms Regulations, export control, State Dept"
    },
    "$.compliance.cato": {
      "hash": "0x1X3Z5B7D",
      "expansion": "Continuous ATO: ongoing visibility, active cyber defense, DevSecOps RD"
    }
  },
  "surfaces": {
    "$.surface.slack.orbital": {
      "hash": "0xSL01ORBT",
      "expansion": "/orbital status|health - constellation overview and health check"
    },
    "$.surface.slack.sat": {
      "hash": "0xSL02SATS",
      "expansion": "/sat list|info <id> - list satellites or get details"
    },
    "$.surface.slack.station": {
      "hash": "0xSL03STAT",
      "expansion": "/station list|info|add - manage 257 ground stations"
    },
    "$.surface.slack.routing": {
      "hash": "0xSL04ROUT",
      "expansion": "/routing status|optimize - check and optimize routing"
    },
    "$.surface.slack.backtest": {
      "hash": "0xSL05BACK",
      "expansion": "/backtest start|status - run HFT backtests"
    },
    "$.surface.linear": {
      "hash": "0xLN01ORBT",
      "expansion": "Issues=Tasks, Labels=Domain(SAT/STATION/ROUTING/BACKTEST), Project=sx9-orbital"
    }
  }
}
```

### R1 Quick Lookup Table
```
HASH        | KEY                        | SHORT EXPANSION
------------|----------------------------|------------------------------------------
0x7A3F8B2C  | $.orbital.halo             | 12 MEO, 10.5Mm, Walker 3/4
0x2D4E6F8A  | $.orbital.walker           | i:t/p/f notation
0x9B1C3D5E  | $.orbital.sgp4             | TLE → ECI position/velocity
0x4F6A8C2E  | $.ground.stations          | 257 Airbus FSO, validated coords
0x1E3G5I7K  | $.ground.fso               | 200Gbps, weather dependent
0x8H2J4L6N  | $.routing.ann              | Weather+pos+demand → path
0x3M5O7Q9S  | $.routing.backtest         | 5yr HFT Monte Carlo
0x6P8R0T2V  | $.routing.quality          | opt+geo+atm+avail → composite
0x9J1L3N5P  | $.coord.geodetic           | VALIDATE lat/lon/alt
0xSL01ORBT  | $.surface.slack.orbital    | /orbital status|health
0xSL02SATS  | $.surface.slack.sat        | /sat list|info
0xSL03STAT  | $.surface.slack.station    | /station list|info|add
0xSL04ROUT  | $.surface.slack.routing    | /routing status|optimize
0xSL05BACK  | $.surface.slack.backtest   | /backtest start|status
0xLN01ORBT  | $.surface.linear           | Issues=Tasks, Labels=Domain
```

---

## R2: TASK CONTEXT REGISTER (Per-Task Loading)

### Schema
```json
{
  "task": {
    "id": "string",
    "source": "linear|github|slack|cli",
    "type": "feature|bug|refactor|docs|test|backtest",
    "title": "string",
    "description": "string",
    "domain": "satellite|station|routing|backtest|weather|compliance"
  },
  "scope": {
    "crates": ["orbital-mechanics", "beam-routing"],
    "files": ["src/routing.rs", "src/types.rs"],
    "apis": ["/api/routing/optimize"],
    "slack_commands": ["/routing optimize"]
  },
  "context": {
    "related_issues": [],
    "blocking": [],
    "blocked_by": [],
    "recent_commits": []
  },
  "constraints": {
    "zone": "C",
    "complexity_budget": 12,
    "test_coverage_min": 85
  }
}
```

### Example Task Load
```json
{
  "task": {
    "id": "ORB-42",
    "source": "linear",
    "type": "feature",
    "title": "Implement beam quality scoring",
    "description": "Add BeamQuality struct with composite scoring",
    "domain": "routing"
  },
  "scope": {
    "crates": ["beam-routing"],
    "files": ["src/quality.rs"],
    "apis": ["/api/links/{id}/quality"],
    "slack_commands": ["/routing status"]
  },
  "constraints": {
    "zone": "C",
    "complexity_budget": 10,
    "test_coverage_min": 90
  }
}
```

---

## R3: RECENT DECISIONS REGISTER (Sliding Window)

### Schema
```json
{
  "decisions": [
    {
      "timestamp": "ISO8601",
      "type": "routing|station|backtest|gate|config",
      "action": "string",
      "actor": "system|human:name|slack:command",
      "rationale": "string",
      "outcome": "success|failure|pending",
      "surface": "slack|linear|cli|api"
    }
  ],
  "max_entries": 50,
  "retention_hours": 168
}
```

### Example Decisions
```json
{
  "decisions": [
    {
      "timestamp": "2026-01-04T15:30:00Z",
      "type": "station",
      "action": "add_station GS-TEST-001",
      "actor": "slack:/station add",
      "rationale": "New Denver ground station for coverage improvement",
      "outcome": "success",
      "surface": "slack",
      "details": {"lat": 39.7392, "lon": -104.9903, "alt": 1609}
    },
    {
      "timestamp": "2026-01-04T14:00:00Z",
      "type": "routing",
      "action": "path_optimization",
      "actor": "slack:/routing optimize",
      "rationale": "Cloud cover over Station-42, reroute via Station-78",
      "outcome": "success",
      "surface": "slack",
      "details": {"old_quality": 0.3, "new_quality": 0.87, "routes_updated": 847}
    },
    {
      "timestamp": "2026-01-04T12:00:00Z",
      "type": "backtest",
      "action": "start BT-2026-001",
      "actor": "slack:/backtest start",
      "rationale": "2024 full year backtest for routing validation",
      "outcome": "pending",
      "surface": "slack",
      "details": {"start": "2024-01-01", "end": "2024-12-31", "progress": 67}
    }
  ]
}
```

---

## MEMORY LOADING SEQUENCE

```
1. BOOT
   └─► Load R0 (Identity + Surfaces) - ALWAYS, ~600 tokens
   
2. DOMAIN INIT
   └─► Load R1 (Domain Knowledge + Surface Commands) - ALWAYS, ~2500 tokens
   
3. TASK ASSIGNMENT
   ├─► Slack command → Load R2 with command context
   ├─► Linear issue → Load R2 with task scope
   └─► GitHub event → Load R2 with PR/commit context
   
4. EXECUTION
   └─► Append to R3 (Decisions) - CONTINUOUS
   └─► Prune R3 when > 50 entries or > 168 hours old
   
5. SYNC
   └─► Push state to Linear (issue updates)
   └─► Post to Slack (status messages)
   └─► Update D1/KV (canonical state)
   
6. PERSIST
   └─► Write R3 to Sled on task completion
```

---

## T-LINE COMPRESSION MAPPINGS

```toml
# Orbital domain T-Lines for prompt compression
[t-lines.orbital]
"Walker Delta 3/4 constellation" = "$.orbital.walker"
"12 MEO satellites at 10500km" = "$.orbital.halo"
"SGP4 propagation from TLE" = "$.orbital.sgp4"
"257 Airbus ground stations" = "$.ground.stations"
"Free-space optical links" = "$.ground.fso"
"ANN/CNN routing optimization" = "$.routing.ann"
"5-year weather backtesting" = "$.routing.backtest"
"Beam quality composite score" = "$.routing.quality"
"Validate latitude longitude" = "$.coord.geodetic"
"ITAR export compliance" = "$.compliance.itar"
"Continuous ATO requirements" = "$.compliance.cato"

[t-lines.surfaces]
"Slack orbital commands" = "$.surface.slack.orbital"
"Slack satellite commands" = "$.surface.slack.sat"
"Slack station commands" = "$.surface.slack.station"
"Slack routing commands" = "$.surface.slack.routing"
"Slack backtest commands" = "$.surface.slack.backtest"
"Linear project integration" = "$.surface.linear"
```

---

## SKILLS REGISTRY

```json
{
  "skills": {
    "code.generate": {
      "zone": "D",
      "latency_ms": 5000,
      "description": "Generate Rust code for orbital/routing domain",
      "llm_allowed": true
    },
    "code.review": {
      "zone": "D", 
      "latency_ms": 3000,
      "description": "Review code for zone compliance, complexity",
      "llm_allowed": true
    },
    "test.generate": {
      "zone": "D",
      "latency_ms": 4000,
      "description": "Generate unit/integration tests",
      "llm_allowed": true
    },
    "docs.generate": {
      "zone": "D",
      "latency_ms": 2000,
      "description": "Generate documentation from code",
      "llm_allowed": true
    },
    "routing.analyze": {
      "zone": "C",
      "latency_ms": 50,
      "description": "Analyze routing decision (NO LLM)",
      "llm_allowed": false
    },
    "quality.score": {
      "zone": "C",
      "latency_ms": 10,
      "description": "Calculate beam quality (NO LLM)",
      "llm_allowed": false
    },
    "station.validate": {
      "zone": "B",
      "latency_ms": 1,
      "description": "Validate station coordinates (NO LLM)",
      "llm_allowed": false
    },
    "slack.respond": {
      "zone": "D",
      "latency_ms": 500,
      "description": "Format and send Slack response",
      "llm_allowed": false
    },
    "linear.sync": {
      "zone": "D",
      "latency_ms": 800,
      "description": "Sync state to Linear",
      "llm_allowed": false
    }
  }
}
```

---

## INFERENCE RULES (Deterministic)

```rust
// Rules applied in Inferrer stage - NO LLM in gate logic
pub const ORBITAL_INFERENCE_RULES: &[InferenceRule] = &[
    // Coordinate validation
    InferenceRule {
        trigger: "ground station",
        infers: ["validate_coordinates", "check_elevation_mask"],
        confidence: 1.0,
    },
    InferenceRule {
        trigger: "station add",
        infers: ["validate_coordinates", "create_linear_issue", "notify_slack"],
        confidence: 1.0,
    },
    
    // Routing
    InferenceRule {
        trigger: "routing",
        infers: ["weather_check", "backup_paths", "quality_score"],
        confidence: 1.0,
    },
    InferenceRule {
        trigger: "routing optimize",
        infers: ["run_ann", "update_routing_table", "notify_slack"],
        confidence: 1.0,
    },
    
    // Satellite ops
    InferenceRule {
        trigger: "satellite position",
        infers: ["sgp4_propagation", "tle_required"],
        confidence: 0.95,
    },
    
    // Beam links
    InferenceRule {
        trigger: "beam link",
        infers: ["fso_constraints", "slew_limits", "atmospheric_model"],
        confidence: 0.9,
    },
    
    // Backtest
    InferenceRule {
        trigger: "backtest start",
        infers: ["load_weather_data", "init_simulation", "notify_slack"],
        confidence: 1.0,
    },
    
    // Surface sync
    InferenceRule {
        trigger: "state_change",
        infers: ["sync_linear", "post_slack"],
        confidence: 0.9,
    },
];
```

---

## SLACK COMMAND HANDLERS

```typescript
// Handler mapping for orbital-worker
const SLACK_HANDLERS = {
  '/orbital': {
    'status': handleOrbitalStatus,
    'health': handleOrbitalHealth,
  },
  '/sat': {
    'list': handleSatList,
    'info': handleSatInfo,
  },
  '/station': {
    'list': handleStationList,
    'info': handleStationInfo,
    'add': handleStationAdd,  // Triggers coordinate validation
  },
  '/routing': {
    'status': handleRoutingStatus,
    'optimize': handleRoutingOptimize,
  },
  '/backtest': {
    'start': handleBacktestStart,
    'status': handleBacktestStatus,
  },
};
```

---

## LINEAR SYNC RULES

```typescript
// When to sync to Linear
const LINEAR_SYNC_TRIGGERS = [
  { event: 'station_added', action: 'create_issue', label: 'STATION' },
  { event: 'backtest_complete', action: 'update_issue', label: 'BACKTEST' },
  { event: 'routing_optimized', action: 'add_comment', label: 'ROUTING' },
  { event: 'gate_failed', action: 'create_issue', label: 'COMPLIANCE' },
  { event: 'phase_advanced', action: 'update_labels', label: 'PHASE' },
];
```

---

## LOAD COMMAND

```bash
# Load this memory configuration into agent harness
sx9-agent load-memory \
  --system sx9-orbital \
  --r0 ./memory/r0-identity.json \
  --r1 ./memory/r1-domain.json \
  --skills ./memory/skills.json \
  --inference ./memory/inference-rules.json \
  --surfaces ./memory/surfaces.json

# Or via CLI
sx9-orbital agent-init --full --with-surfaces
```

---

*End of sx9-orbital Memory Configuration v2.0*
