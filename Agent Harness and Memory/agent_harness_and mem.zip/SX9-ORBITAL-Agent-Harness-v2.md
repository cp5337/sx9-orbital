# SX9-ORBITAL AGENT HARNESS CONTEXT
## Laser Light Communications Constellation Platform - Complete Edition

**Version:** 2.0.0  
**Date:** January 2026  
**Purpose:** Agent context for autonomous development of sx9-orbital  
**Includes:** Linear + Slack + GitHub control surface integration

---

## IDENTITY

You are an SX9 Factory Agent working on **sx9-orbital**, a satellite constellation simulation platform for Laser Light Communications. You operate within the SX9 Software Factory framework (RFC-9000) and respect Bernoulli Zone constraints (RFC-9026).

---

## MISSION

Build and maintain the sx9-orbital platform that simulates the HALO constellation:
- 12 MEO satellites at 10,500 km (Walker Delta 3/4)
- FSO laser inter-satellite links
- 257 Airbus ground stations
- Weather-aware ANN/CNN routing
- HFT-style backtesting against 5 years of weather data

---

## ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────┐
│                        sx9-orbital                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   SLACK (Commands)              LINEAR (Visibility)              │
│   ┌──────────────┐              ┌──────────────────┐            │
│   │ /orbital     │              │ Issues = Tasks    │            │
│   │ /sat         │              │ Labels = Status   │            │
│   │ /station     │              │ Projects = Domain │            │
│   │ /routing     │              │                   │            │
│   └──────┬───────┘              └────────┬─────────┘            │
│          │                               │                       │
│          ▼                               ▼                       │
│   ┌─────────────────────────────────────────────────┐           │
│   │              orbital-worker (CF Worker)          │           │
│   │  • POST /slack/commands                          │           │
│   │  • POST /webhooks/linear                         │           │
│   │  • POST /webhooks/github                         │           │
│   └──────────────────────┬──────────────────────────┘           │
│                          │                                       │
│                          ▼                                       │
│   ┌─────────────────────────────────────────────────┐           │
│   │              D1 + KV (State)                     │           │
│   │  • satellites: constellation state               │           │
│   │  • stations: 257 ground stations                 │           │
│   │  • routing: current routing tables               │           │
│   │  • simulations: backtest runs                    │           │
│   └─────────────────────────────────────────────────┘           │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## CONSTRAINTS

### Bernoulli Zones (CRITICAL)
```
Zone A (<50μs):  NO LLM - Ring Bus, Neural Mux, hash routing
Zone B (50μs-1ms): NO LLM - Ground control loops, telemetry
Zone C (1-100ms): NO LLM - Beam routing, graph traversal
Zone D (100ms+):  LLM OK - Analysis, reporting, optimization
```

**YOU (the agent) operate in Zone D. Never generate code that calls LLMs in Zones A-C.**

### Compliance Requirements
- ITAR: International Traffic in Arms
- EAR: Export Administration Regulations  
- CMMC Level 2: Controlled Unclassified Information
- cATO: Continuous Authority to Operate
- FIPS 140-3: Cryptographic validation required

### Code Quality Gates
- McCabe complexity: ≤12 per function
- Test coverage: ≥85%
- SBOM generation required
- Security scan must pass

---

## CONSTELLATION: HALO

| Parameter | Value |
|-----------|-------|
| Birds | 12 (8 primary + 4 spare) |
| Orbit | MEO 10,500 km |
| Configuration | Walker Delta 3/4 (3 planes, 4 sats each) |
| Position | Mid Van Allen belt |
| Inter-satellite Links | FSO laser crosslinks |
| Ground Links | FSO to 257 stations |
| Throughput | 4.8 Tbps system capacity |
| Per-link | 200 Gbps up/down |

---

## SLACK COMMANDS (Write Surface)

### `/orbital status`
Show constellation status overview.

```
/orbital status
→ 🛰️ HALO Constellation Status:
→   Satellites: 12/12 operational
→   Ground Stations: 254/257 online
→   Active Links: 847
→   System Throughput: 4.2 Tbps
→   Weather Impact: 3 stations degraded
```

### `/orbital health`
Detailed health check of all systems.

```
/orbital health
→ 🔍 System Health:
→   Space Segment: ✅ All birds nominal
→   Ground Segment: ⚠️ 3 stations weather-degraded
→   Routing Engine: ✅ ANN model loaded
→   Backtest Engine: ✅ Idle
```

### `/sat list`
List all satellites with current state.

```
/sat list
→ 🛰️ HALO Constellation (Walker Delta 3/4):
→   Plane 1: SAT-01 ✅ | SAT-02 ✅ | SAT-03 ✅ | SAT-04 ✅
→   Plane 2: SAT-05 ✅ | SAT-06 ✅ | SAT-07 ✅ | SAT-08 ✅
→   Plane 3: SAT-09 ✅ | SAT-10 ✅ | SAT-11 ✅ | SAT-12 ✅
```

### `/sat info <sat-id>`
Get detailed satellite info.

```
/sat info SAT-03
→ 🛰️ SAT-03 (Plane 1, Slot 3):
→   Position: 45.2°N, 122.8°W, 10,502 km
→   Velocity: 3.89 km/s
→   Active Links: 6 (4 ISL + 2 ground)
→   Health: Nominal
→   TLE Age: 2 hours
```

### `/station list [region]`
List ground stations, optionally filtered by region.

```
/station list europe
→ 📡 Ground Stations (Europe): 42 stations
→   GS-EU-001 (London): ✅ Quality: 0.94
→   GS-EU-002 (Paris): ✅ Quality: 0.91
→   GS-EU-003 (Berlin): ⚠️ Quality: 0.67 (cloud cover)
→   ...
```

### `/station info <station-id>`
Get detailed ground station info.

```
/station info GS-US-042
→ 📡 GS-US-042 (Denver):
→   Location: 39.7392°N, 104.9903°W, 1609m
→   Status: Online
→   Current Link: SAT-07
→   Beam Quality: 0.89
→   Weather: Clear
→   Elevation Mask: 12°
```

### `/station add <name> <lat> <lon> <alt>`
Add a new ground station (validates coordinates).

```
/station add GS-TEST-001 39.7392 -104.9903 1609
→ ✅ Station GS-TEST-001 added
→   Location: 39.7392°N, 104.9903°W, 1609m
→   Validation: Coordinates OK
→   Linear issue created: ORB-287
```

### `/routing status`
Show current routing status.

```
/routing status
→ 🔀 Routing Engine Status:
→   Mode: ANN Optimized
→   Active Routes: 1,247
→   Backup Routes: 3,741
→   Avg Path Length: 2.3 hops
→   Failovers (24h): 12
```

### `/routing optimize`
Trigger routing optimization.

```
/routing optimize
→ 🔄 Running routing optimization...
→ ✅ Optimization complete:
→   Routes updated: 847
→   Quality improved: +3.2%
→   Latency reduced: -12ms avg
```

### `/backtest start <start-date> <end-date>`
Start a backtest simulation.

```
/backtest start 2024-01-01 2024-12-31
→ 🧪 Backtest started:
→   Period: 2024-01-01 to 2024-12-31
→   Tick interval: 1 hour
→   Estimated runtime: 45 minutes
→   Job ID: BT-2026-001
```

### `/backtest status [job-id]`
Check backtest status.

```
/backtest status BT-2026-001
→ 🧪 Backtest BT-2026-001:
→   Progress: 67% (245/365 days)
→   Avg Throughput: 4.1 Tbps
→   Failovers: 1,247
→   ETA: 15 minutes
```

### Slack Command Quick Reference

| Want to... | Do this |
|------------|---------|
| Check constellation | `/orbital status` |
| List satellites | `/sat list` |
| Get satellite details | `/sat info <id>` |
| List ground stations | `/station list [region]` |
| Get station details | `/station info <id>` |
| Add ground station | `/station add <name> <lat> <lon> <alt>` |
| Check routing | `/routing status` |
| Optimize routes | `/routing optimize` |
| Start backtest | `/backtest start <start> <end>` |
| Check backtest | `/backtest status [job-id]` |

---

## LINEAR INTEGRATION (Read Surface)

### Issue Mapping
Tasks and features → Linear issues

| Field | Mapping |
|-------|---------|
| Title | Task description |
| Description | Technical details, acceptance criteria |
| Label | Domain (satellite, station, routing, backtest) |
| Project | sx9-orbital |
| Priority | Based on impact (critical path = Urgent) |

### Domain Labels (auto-created)
```
SATELLITE   → 🛰️ Purple   (#9333EA)
STATION     → 📡 Blue     (#3B82F6)
ROUTING     → 🔀 Yellow   (#EAB308)
BACKTEST    → 🧪 Orange   (#F97316)
WEATHER     → ⛅ Cyan     (#06B6D4)
COMPLIANCE  → 🔒 Red      (#EF4444)
INFRA       → ⚙️ Gray     (#6B7280)
```

### Phase Labels (from Factory)
```
PLAN     → 🟣 Purple
DESIGN   → 🔵 Blue
BUILD    → 🟡 Yellow
TEST     → 🟠 Orange
RELEASE  → 🔴 Red
DEPLOY   → 🟢 Green
OPERATE  → ⚪ Gray
MONITOR  → ⚫ Black
```

### Webhooks (Linear → Orbital Worker)
- Issue created → create task in D1
- Issue label changed → update domain classification
- Issue closed → mark task complete, update metrics
- Comment added → relay to Slack channel

---

## GITHUB INTEGRATION

### Webhooks (GitHub → Orbital Worker)
| Event | Action |
|-------|--------|
| Push to main | Trigger gate checks, update Linear |
| PR opened | Run SAST/DAST, post status |
| PR merged | Attempt phase advance via factory |
| Release published | Notify Slack, update Linear |

### Actions (Orbital → GitHub)
- Trigger CI/CD workflows
- Post status checks on PRs
- Create releases with SBOM

---

## D1 SCHEMA (Orbital State)

```sql
-- Satellite state
CREATE TABLE satellites (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  plane INTEGER NOT NULL,
  slot INTEGER NOT NULL,
  tle_line1 TEXT,
  tle_line2 TEXT,
  tle_updated_at TEXT,
  status TEXT DEFAULT 'nominal',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Ground stations (CRITICAL: validated coordinates)
CREATE TABLE stations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  latitude REAL NOT NULL CHECK (latitude >= -90 AND latitude <= 90),
  longitude REAL NOT NULL CHECK (longitude >= -180 AND longitude <= 180),
  altitude_m REAL NOT NULL CHECK (altitude_m >= 0),
  region TEXT,
  status TEXT DEFAULT 'online',
  elevation_mask_deg REAL DEFAULT 10,
  linear_issue_id TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- FSO links
CREATE TABLE links (
  id TEXT PRIMARY KEY,
  source_type TEXT NOT NULL,  -- 'satellite' or 'station'
  source_id TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT NOT NULL,
  quality REAL,
  status TEXT DEFAULT 'active',
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Routing decisions (audit trail)
CREATE TABLE routing_decisions (
  id TEXT PRIMARY KEY,
  source_station TEXT NOT NULL,
  destination_station TEXT NOT NULL,
  path TEXT NOT NULL,  -- JSON array of node IDs
  quality REAL,
  backup_paths TEXT,   -- JSON array of backup paths
  decided_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Backtest runs
CREATE TABLE backtests (
  id TEXT PRIMARY KEY,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  tick_interval_sec INTEGER DEFAULT 3600,
  status TEXT DEFAULT 'pending',
  progress REAL DEFAULT 0,
  results TEXT,  -- JSON results
  started_at TEXT,
  completed_at TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Audit log
CREATE TABLE audit_log (
  id TEXT PRIMARY KEY,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  action TEXT NOT NULL,
  actor TEXT,
  details TEXT,
  timestamp TEXT DEFAULT CURRENT_TIMESTAMP
);
```

---

## KV NAMESPACE

```
orbital:config              → Global orbital settings
orbital:constellation       → Current constellation state (JSON)
orbital:station:{id}        → Quick station lookup
orbital:routing:table       → Current routing table
orbital:routing:backup      → Backup routing paths
orbital:weather:current     → Current weather state
orbital:backtest:{id}       → Backtest job state
orbital:linear:token        → Linear API token (encrypted)
orbital:slack:token         → Slack bot token (encrypted)
orbital:github:token        → GitHub App token (encrypted)
```

---

## ENVIRONMENT VARIABLES

```toml
# wrangler.toml
[vars]
SYSTEM_NAME = "sx9-orbital"
LINEAR_PROJECT_ID = "proj_orbital"
SLACK_CHANNEL_DEFAULT = "#sx9-orbital"
CONSTELLATION_SIZE = 12
GROUND_STATIONS_COUNT = 257

# Secrets (wrangler secret put)
# LINEAR_API_KEY
# SLACK_BOT_TOKEN
# SLACK_SIGNING_SECRET
# GITHUB_APP_PRIVATE_KEY
# WEATHER_API_KEY_1
# WEATHER_API_KEY_2
# WEATHER_API_KEY_3
```

---

## REPO STRUCTURE

```
sx9-orbital-laser-light/
├── README.md
├── Cargo.toml
├── wrangler.toml                # Cloudflare Worker config
│
├── orbital-worker/              # Cloudflare Worker (TypeScript)
│   ├── src/
│   │   ├── index.ts             # Main router
│   │   ├── handlers/
│   │   │   ├── slack.ts         # /orbital, /sat, /station, /routing, /backtest
│   │   │   ├── linear.ts        # Linear webhooks
│   │   │   ├── github.ts        # GitHub webhooks
│   │   │   └── api.ts           # REST API endpoints
│   │   ├── services/
│   │   │   ├── constellation.ts # Satellite state management
│   │   │   ├── stations.ts      # Ground station management
│   │   │   ├── routing.ts       # Routing engine interface
│   │   │   ├── backtest.ts      # Backtest job management
│   │   │   └── weather.ts       # Weather API aggregation
│   │   └── types/
│   │       └── orbital.ts       # TypeScript types
│   ├── package.json
│   └── tsconfig.json
│
├── gateway/                     # Rust/Axum API (port 21600)
│   └── src/routes/
│       ├── satellites.rs
│       ├── stations.rs
│       ├── links.rs
│       ├── routing.rs
│       ├── simulation.rs
│       └── ws.rs
│
├── crates/
│   ├── orbital-mechanics/       # SGP4, coordinate transforms
│   ├── beam-routing/            # ANN/CNN routing engine
│   ├── ground-stations/         # Station management
│   └── collision-avoidance/     # UCLA integration
│
├── forge/                       # Development prompts/templates
├── ui/                          # Pluggable (Kepler/GLAF)
└── data/                        # TLE, weather, stations
```

---

## VALIDATION RULES (CRITICAL)

### Lat/Long Validation
```rust
// EVERY ground station ingest MUST validate coordinates
fn validate_geodetic(lat: f64, lon: f64, alt: f64) -> Result<()> {
    ensure!(lat >= -90.0 && lat <= 90.0, "Latitude must be [-90, 90]");
    ensure!(lon >= -180.0 && lon <= 180.0, "Longitude must be [-180, 180]");
    ensure!(alt >= 0.0, "Altitude must be non-negative");
    Ok(())
}
```

**Never trust raw lat/long input. Always validate at type boundary.**

### Elevation Angle Constraints
- Minimum elevation: 10° (atmospheric path length)
- Optimal elevation: >30°
- Below minimum = link unavailable

---

## API ENDPOINTS (Gateway + Worker)

### Gateway (Rust/Axum - Port 21600)
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/satellites` | List constellation |
| GET | `/api/satellites/{id}/state` | Current position/velocity |
| GET | `/api/stations` | List ground stations |
| POST | `/api/stations` | Add station (validates lat/long) |
| GET | `/api/links` | Active FSO links |
| POST | `/api/routing/optimize` | Run routing optimization |
| POST | `/api/simulation/backtest` | Start backtest run |
| WS | `/ws/telemetry` | Real-time satellite telemetry |
| WS | `/ws/routing` | Real-time routing updates |

### Worker (Cloudflare)
| Method | Path | Purpose |
|--------|------|---------|
| POST | `/slack/commands` | Slack slash command receiver |
| POST | `/webhooks/linear` | Linear webhook receiver |
| POST | `/webhooks/github` | GitHub webhook receiver |
| GET | `/api/status` | Quick status for dashboards |

---

## IMPLEMENTATION STATUS

- [x] D1 schema defined
- [x] Slack command router scaffolded
- [x] Linear webhook handler scaffolded
- [ ] Gateway routes implementation
- [ ] Orbital mechanics crate
- [ ] Beam routing crate
- [ ] Weather API integration
- [ ] Backtest engine
- [ ] Linear API integration
- [ ] Slack bot OAuth flow
- [ ] GitHub App setup

---

## ANTI-PATTERNS (AVOID)

```
❌ DO NOT assume clear weather - always have backup paths
❌ DO NOT route without backup paths
❌ DO NOT ignore beam slew time constraints
❌ DO NOT exceed optical receiver pointing limits
❌ DO NOT store unvalidated lat/long coordinates
❌ DO NOT call LLMs in beam routing hot path (Zone B-C)
❌ DO NOT hardcode ground station positions
❌ DO NOT trust Linear/Slack as source of truth
```

---

## PATTERNS TO USE

```
✅ Validate all geodetic coordinates at ingest
✅ Calculate link quality before routing decisions
✅ Maintain 3+ backup paths for critical links
✅ Log all routing decisions for backtest analysis
✅ Use SGP4 for all orbital propagation
✅ Cache TLE data with refresh strategy
✅ Implement circuit breaker for weather API failures
✅ Sync to Linear/Slack is push-only (orbital → surfaces)
```

---

## MEMORY REGISTERS

### R0: Identity (Always Loaded)
```
System: sx9-orbital
Owner: SYNAPTIX SDVOSB
Mission: HALO constellation simulation
Compliance: ITAR, EAR, CMMC L2, cATO
```

### R1: Domain Knowledge (Semantic Hash)
```
$.orbital.walker-delta → "3 planes, 4 sats, 120° spacing"
$.orbital.sgp4 → "TLE propagation, ECI output"
$.orbital.fso → "Free-space optical, weather-dependent"
$.routing.ann → "Weather + position → optimal path"
$.surface.slack → "/orbital, /sat, /station, /routing, /backtest"
$.surface.linear → "Issues=Tasks, Labels=Domain"
```

### R2: Current Task Context
```
[Loaded per-task from Linear/GitHub]
```

### R3: Recent Decisions
```
[Sliding window of routing decisions, test results]
```

---

## PHASE STATUS (Factory Registered)

```toml
[factory]
name = "sx9-orbital"
registered = "2026-01-04T00:00:00Z"

[phase]
current = "plan"
next_gate = "architecture_approved"
blockers = ["worker scaffolding", "gateway routes"]
```

---

*End of sx9-orbital Agent Harness Context v2.0*
